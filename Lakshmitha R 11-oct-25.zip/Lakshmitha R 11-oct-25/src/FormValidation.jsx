
import { useState } from "react";
function SimpleValidation(){
    const[email, setEMail]=useState("");
    const[number,setNum]=useState("")
    const[error,setError]=useState("");
    const[errors,setErrors]=useState("")
    const handleSubmit=(e) => {
        e.preventDefault();
        if(!email.includes("@")){
            setError("Please eneter a valid email");
        }
        else{
            setError("");
            alert(`Email Submitted:${email}`);
        }
        if(number.length!==10){
            setErrors("InValid Number");
        }
        else{
            setErrors("");
            alert(`Number Submitted:${number}`);
        }
        console.log(number);
    };
    return(
        <form onSubmit={handleSubmit}>
            <input type="email" value={email} onChange={(e) => setEMail(e.target.value)}/>
            <input type="number" value={number} onChange={(e) =>setNum(e.target.value)}/>
            <button type="submit">Submit</button>
            {error && <p style={{color:"red"}}>{error}</p>}
            {errors && <p style={{color:"red"}}>{errors}</p>}

        </form>
    );

}
export default SimpleValidation