import React from 'react'
function Parent1({ studentName}){
    return(
        <div style={{background:"#d4f1f4",margin:"10px",padding:"10px"}}>
            <h2>Parent Component</h2>
            <Child studentName={studentName} />
        </div>
    );
}
function Child({ studentName}){
    return(
     <div style={{background:"#a4ebf3",margin:"10px",padding:"10px"}}>
            <h2>Child Component</h2>
            <GrandChild studentName={studentName} />
        </div>
    );

}
function GrandChild({ studentName}){
    return(
     <div style={{background:"#75e6da",margin:"10px",padding:"10px"}}>
            <h2>GrandChild Component</h2>
            <GreatGrandChild studentName={studentName} />
        </div>
    );

}
function GreatGrandChild({ studentName}){
    return(
     <div style={{background:"#189ab4",color:"white",margin:"10px",padding:"10px"}}>
            <h2>GreatGrandChild Component</h2>
            <p>
                Hello<b>{studentName}</b>,this value was passed from the app component through 3 other component
            </p>
        </div>
    );

}
export default Parent1;
