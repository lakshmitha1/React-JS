import React from "react";

class Fruit extends React.Component{
    render(){
        return <h1>Hello This is Class Component</h1>
    }
}
export default Fruit;