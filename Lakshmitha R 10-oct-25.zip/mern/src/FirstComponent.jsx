import React from 'react'

function FirstComponent(lakshmitha) {
  return (
    <div>
        <h1>FirstComponent{lakshmitha.name}</h1>
    <SecondComponent phno="6362043172" />
    
    </div>
  )
}
function SecondComponent(lakshmitha) {
  return (
    <div>SecondComponent{lakshmitha.phno}</div>
  )
}

export default FirstComponent