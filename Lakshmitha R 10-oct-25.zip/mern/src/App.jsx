import React from 'react'
import FirstComponent from './FirstComponent'
import Fruit from './ClassOne'
import Parent from './PropsChildren'
import ClassResult from './ConditionalRendering'
import Car from './LogicalAnd'
import Car1 from './Destructuring1'
import Care from './Destructuring2'
import Parent1 from './PropDrilling'




function App() {
  return (
   <div>
     {/* <FirstComponent name="lakshmitha" />     
      <FirstComponent name="lakshmitha" />     
       <FirstComponent name="lakshmitha" />
       <Fruit /> 
       <Parent />    */}
       <ClassResult isresult={false}/>
       <Car brand="THAR" />
       <Car1 color="Red" />
       <Care brand="Ford" model="Mustang"  />
       <Parent1 studentName="lakshmitha" />
       
   </div>                                                
  )
}



export default App
