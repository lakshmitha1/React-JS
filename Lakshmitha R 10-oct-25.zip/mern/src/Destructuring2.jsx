import React from 'react'

function Care(props){
    const {brand, model} = props;
    return(
        <h2>I Love my {brand}{model} </h2>
    );
 
}
export default Care