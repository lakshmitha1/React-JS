// import Todo from "./ToDo";
import React from "react";
import {QueryClient, QueryClientProvider} from "@tanstack/react-query";
import Post from "./Post";
const client = new QueryClient();

function App(){
  return(
    <QueryClientProvider client={client}>
      <div>
        <Post/>
      </div>

    </QueryClientProvider>
    
  )
}
export default App