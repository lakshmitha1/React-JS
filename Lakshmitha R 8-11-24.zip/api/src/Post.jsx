import { useQuery } from '@tanstack/react-query';
import react from 'react'
function Post(){
    const {data,isLoading,isfetching, isError}=useQuery({
        querykey:["images"],
        queryFn:()=>
            fetch("https://picsum.photos/v2/list?page=2&limit=10").then((res) => res.json())
    });
    if(isLoading) return <p>Loading Images..</p>
    if(isError) return <p>Error Loading Images</p>
    
    return(
<div>
    <h2>Posts List</h2>
    {data.map((img)=>(
        <div key={img.id}>
            <img src={img.download_url} alt={img.author} />
            <p>{img.author}</p>
            </div>
 
    ))}

</div>
    )
}
export default Post;