import React from 'react'
import axios from 'axios';
import { useState,useEffect } from 'react';
function Todo(){
    const[todos,setTodos]=useState([]);
    const[loading,setLoading]=useState(false);
    const[error,setError]=useState(null);
    const[limit,setLimit]=useState(10);
    useEffect(()=>{
        axios.get("https://jsonplaceholder.typicode.com/todos/")
        .then(res=>setTodos(res.data))
        .catch(err=>setError(err));
},[]);
const handleLoadMore=() =>{
    setLimit((preveLimit)=>preveLimit + 5);
}
    if(error) return <p>❌Error Fetching Todo:{error.message}</p>
    if(loading) return <p>⌛Loading...</p>


    return (
  <div>
    <h1>Todo List</h1>
    {todos.slice(0, limit).map((todo) => (
      <div
        style={{
          ...StyleSheet.todos,
          backgroundColor: todo.completed ? "green" : "red",
        }}
        key={todo.id}
      >More
        <h3>{todo.title}</h3>
        <p>Status: {todo.completed ? "completed" : "pending"}</p>
      </div>
    ))}
    {limit < todos.length && (
          <button  style={{backgroundColor:"green"}}onClick={handleLoadMore}>Load </button>
    )}
  </div>
);


}
export default Todo