import React from 'react'
import Dashboard from './Dashboard'
import Login from './Login'
import { BrowserRouter } from 'react-router-dom'
import { Routes,Route } from 'react-router-dom'
import ProtectedRoute from './ProtectedRoute'

function App(){
  return(
    <BrowserRouter>
    <Routes>
      {/*Public Route */}
      <Route path="/Login" element={<Login/>}/>
      {/* <Route path="/" element={<Home/>}/> */}
      {/*Protected Route*/}
      <Route path="/dashboard" element={
      <ProtectedRoute>
        <Dashboard />
        </ProtectedRoute>   
      }/>      
     
    </Routes>
    </BrowserRouter>

  )

  
}
export default App