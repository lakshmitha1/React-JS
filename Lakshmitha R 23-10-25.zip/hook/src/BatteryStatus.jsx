// BatteryStatus.jsx
import React from "react";

const BatteryStatus = ({ level, charging, chargingTime, dischargingTime }) => (
  <div>
    <p>🔋 Battery Level: {level}%</p>
    <p>⚡ Charging: {charging ? "Yes" : "No"}</p>
    <p>⏱️ Charging Time: {chargingTime ? `${chargingTime} seconds` : "N/A"}</p>
    <p>⏳ Discharging Time: {dischargingTime ? `${dischargingTime} seconds` : "N/A"}</p>
  </div>
);

export default BatteryStatus;
