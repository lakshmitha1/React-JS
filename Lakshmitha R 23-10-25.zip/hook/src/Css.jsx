import React from 'react'
const style={
    backgroundColor:"lightblue",
    padding:"10px",
    borderRadius:"5px",
};
//Dynamic Inline css
function Temperature({ value }){
    return (
        <p style={{ color:value > 30 ? "red" : "blue"}}>Temperature:{value}C</p>
    );
}
export default Temperature
