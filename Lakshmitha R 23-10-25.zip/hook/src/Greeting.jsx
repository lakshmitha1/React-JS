import React from 'react'
const style={
    backgroundColor:"lightblue",
    padding:"10px",
    borderRadius:"5px",
};
//Static Inline CSS
function Greeting(){
    return <h2   style={style}>Hello Inline Styling</h2>
}
export default Greeting