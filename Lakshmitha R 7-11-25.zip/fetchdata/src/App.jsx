import React, { useEffect, useState } from 'react';

function App() {
  const [images, setImages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const loadImages = async () => {
      console.log("➡️ Fetching images from Picsum API");

      try {
        const res = await fetch("https://picsum.photos/v2/list");
        console.log('API Response Status:', res.status);
        if (!res.ok) throw new Error(`Network response not ok: ${res.status}`);

        const data = await res.json();
        console.log("Fetched Data:", data);

        setImages(data);
      } catch (err) {
        console.log("Error fetching images:", err);
        setError(err);
      } finally {
        console.log("Fetch operation complete");
        setLoading(false);
      }
    };

    loadImages();
  }, []);

  if (loading) return <p>Loading Photos...</p>;
  if (error) return <p>Failed to Load Photos 😔</p>;

  return (
    <div>
      <h1>Photo Gallery</h1>
      {images.map((img) => (
        <div key={img.id}>
          <img src={img.download_url} alt={img.author} />
          <p>{img.author}</p>
        </div>
      ))}
    </div>
  );
}

export default App;
