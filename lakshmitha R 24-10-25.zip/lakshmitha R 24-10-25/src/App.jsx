import React from 'react'
import Counter from './Counter'
import Counter2 from './Counter2'
import WithUsememo from './useMemo'
import Parent from './CallBack'
import CounterApp from './CounterApp'

function App() {
  return (
    <div>
      {/* <Counter />
      <Counter2 /> */}
      {/* <WithUsememo /> */}
      {/* <Parent /> */}
      <CounterApp />
    </div>
  )
}

export default App