import React,{useReducer} from 'react';
function Counter(){
    function reducers(state,action){
        switch(action.type){
            case "INCREMENT":
             return {count:state.count+1};
              case "DECREMENT":
             return {count:state.count-1};
             case "RESET":
                return {count:0};
             default:
                return state;
        }
    }
    const[state,dispatch]=useReducer(reducers,{count:0});
    //Initialise state using usereducer
    return (
        <div style={{textAlign:"center",marginTop:"50px"}}>
            <h2>Count:{state.count}</h2>
            <button onClick={()=> dispatch({type:"INCREMENT"})}>INCREMENT</button>
             <button onClick={()=> dispatch({type:"DECREMENT"})}>DECREMENT</button>
            <button onClick={()=> dispatch({type:"RESET"})}>Reset</button>
        </div>
    );
   
}
  export default Counter;