import React,{useState,useMemo} from 'react';
function WithUsememo(){
    const [count,setCount]=useState(0);
    function slowCalculation(num){
        console.log('Running slow Calculation');
        for(let i=0;i<100000000;i++){}
        return num*2;
 
    }
    //usememo caches the result until count changes
    const result=useMemo(()=>slowCalculation(count),[count]);
    console.log(count);
    return(
        <div>
            <h3>Slow result:{result}</h3>
            <button onClick={() => setCount(count+1)}>Increment</button>
        </div>
    )
}
export default WithUsememo;