import React from 'react'

function Home() {
  return (
    <div>
        <h1>This is Home</h1>
    </div>
  )
}

export default Home