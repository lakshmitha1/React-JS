import React from 'react'
import { BrowserRouter,Route } from 'react-router-dom'

function ProtectedRouter() {
  return (
    <div>
        <Route
    </div>
  )
}

export default ProtectedRouter