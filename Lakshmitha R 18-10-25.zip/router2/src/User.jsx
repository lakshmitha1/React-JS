import React from 'react';
import { useParams } from 'react-router-dom';

function User() {
  const { Lakshmitha } = useParams();
  return (
    <div>
      <h2>UserId: {Lakshmitha}</h2>
    </div>
  );
}

export default User;
