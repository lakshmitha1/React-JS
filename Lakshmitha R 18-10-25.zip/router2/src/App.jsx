import React from "react";
import {lazy,Suspense}  from "react"
import {BrowserRouter,Routes,Route,} from "react-router-dom"
const Home=lazy(() => import("./Home"));
const About=lazy(()=> import("./About"));
const Contact=lazy(()=> import("./Contact"));
import User from './User';
import Lazy from './Lazy';

function App() {
  return (
    <div>
    {/* <BrowserRouter>
      <Routes>
        <Route path="/users/:Lakshmitha" element={<User />} />
      </Routes>
    </BrowserRouter>
    <Lazy /> */}
     <Suspense fallback={<h3>Loading...</h3>}>
     <BrowserRouter>
                <Routes>
                    <Route path="/" element={<Home />}/>
                    <Route path="/about" element={<About />}/>
                    <Route path="/contact" element={<Contact />}/>
    
                </Routes>
                </BrowserRouter>
            </Suspense>
    </div>
  );
}

export default App;
