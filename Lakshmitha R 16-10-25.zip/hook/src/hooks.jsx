import React, { useEffect } from "react";
function Example() {
    useEffect(() => {
        console.log("Componen rendered or Updated");
    });
    return <h2>Hello React useEffect</h2>
}
export default Example