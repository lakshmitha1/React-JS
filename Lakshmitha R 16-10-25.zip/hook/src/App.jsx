import Example from "./hooks";
import Counter from "./Counter";
import Cleanup from "./CleanUp";
import UsersList from "./UserList";
import Greeting from "./Greeting";
import Temperature from "./Css";
function App(){
  return (
    <div>
      <Example />
      <Counter />
      <Cleanup />
      <UsersList />
      <Greeting />
      <Temperature />
    </div>
  )
}
export default App