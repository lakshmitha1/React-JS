// 
//Portal
import React from 'react' 
import Modal1 from './Modal1'
import { useState } from 'react'

function App() {
  const [open,setOpen]=useState(false)
  return (
   <>
   <button onClick={()=>setOpen(true)} style={{backgroundColor:"blue"}}>Open Modal</button>
   {open && (<Modal1>
    <div style={{backgroundColor:"pink"}}>
        <div>
            Hello This is a notification
            </div>
            <div>
            <button onClick={()=>setOpen(false)} style={{backgroundColor:"red"}}>Close</button>
        </div>
        </div>
    
   </Modal1>)}
   </>
  )
}

export default App

//Fragments
// import React from 'react'


// function App() {
//   return (
//     <>
//     <div style={{backgroundColor:"red"}}>
//       <h2>Lakshmitha</h2>
//       <p>developer</p>
//       </div>
//       <React.Fragment>
//       <div style={{backgroundColor:"pink"}}>
      
//       <h2>Priya</h2>
//       <p>Tester</p>
//       </div>
//       </React.Fragment>
      
//       </>
      
    
//   )
// }

// export default App
