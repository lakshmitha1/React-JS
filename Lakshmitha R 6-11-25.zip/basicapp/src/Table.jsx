import React from 'react'

function Table() {
    const stylerow1={
        color:"yellow",
        backgroundColor:"red",
    

    }
    const cell1={
        border:"2px solid #000"
    }
    const stylerow2={
        color:"white",
        backgroundColor:"blue",

    }
    const cell2={
        border:"2px solid #000"
    }

  return (
   <>
   <tr style={stylerow1}>
    <td style={cell1}>Lakshmitha</td>
    <td style={cell1}>React Developer</td>
   </tr>
    <tr style={stylerow2}>
    <td style={cell2}>Priya</td>
    <td style={cell2}>React Developer</td>
   </tr>
   </>
  )
}

export default Table