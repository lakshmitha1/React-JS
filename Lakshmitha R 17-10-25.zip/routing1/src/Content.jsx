import React from 'react'

function Content() {
  return (
  <div>
    <h1>This is content page</h1>
  </div>
  )
}

export default Content