import React from 'react'
import {BrowserRouter,Routes,Route} from 'react-router-dom'
import Content from './Content'
import Index from './Index'
import About from './About'
import Home from './Home'


function App() {
  return (
    <div>
      <h1>App</h1>
      <BrowserRouter>
      <Routes>
        <Route path='/' element={<Index />} />
         <Route path='/home' element={<Home />} />
          <Route path='/contact' element={<Content />} />
           <Route path='/about' element={<About />} />

      </Routes>
      </BrowserRouter>
    </div>
  )
}

export default App