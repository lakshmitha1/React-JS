import React from 'react'

function About() {
  return (
    <h>This is about page</h>
  )
}

export default About